/**
 * Created by Justin on 5/23/16.
 */
var mongoose = require('mongoose');

var productSchema = new mongoose.Schema({
    name:          String,
    category:      { type: mongoose.SchemaTypes.ObjectId,
                      ref: 'Categories'},
    slug:          String,
    imageURL:      String,
    imagePath:     String,
    description:   String,
    rating:        Number,
    quantity:      Number,
    price:         Number,
    date:          { type: Date, default: Date.now },
    discountPrice: Number,
    attribute:     []
});

module.exports = mongoose.model('Products', productSchema);